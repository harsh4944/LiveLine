# LiveLine — setup

## Step 1: Get it running today (CPU, no Snapdragon setup needed)

```bash
pip install -r requirements.txt
python live_demo.py --backend cpu --chunk 4
```

Speak into your mic — you'll see timestamped captions print live, and a
`transcript.txt` file will be written. This lets you start building the
overlay UI (Day 2) immediately, without waiting on NPU setup.

## Step 2: Confirm your exact Snapdragon chipset

```powershell
# Windows PowerShell
Get-CimInstance Win32_Processor | Select-Object Name
```

Match the result against the chipset table on the model page, e.g.:
https://aihub.qualcomm.com/mobile/models/whisper_tiny

You need the exact chipset name (X Elite / X2 Elite / 8 Gen 3, etc.) —
the pre-compiled NPU binaries are chipset-specific.

## Step 3: Install the NPU path and confirm its real API

```bash
pip install "qai_hub_models[whisper_tiny_en]"
```

Sign up at https://aihub.qualcomm.com, create an API token under
Account → Settings → API Token, then:

```bash
qai-hub configure --api_token YOUR_TOKEN
```

Before touching `engine.py`, look at what's actually installed —
the library's internal API has shifted across versions, so trust your
installed copy over any remembered snippet:

```bash
python -m qai_hub_models.models.whisper_tiny_en.demo --help
python -c "import qai_hub_models.models.whisper_tiny_en.demo as d; print(d.__file__)"
```

Open the file that second command prints — it's short and shows exactly
how the demo loads the model and calls transcription. Copy those two
calls into the `TODO`s in `engine.py`'s `QNNWhisperEngine`.

## Step 4: Run the NPU version and capture your benchmark

```bash
python live_demo.py --backend qnn --chunk 4
```

The avg latency printed at the end, next to the CPU run's number, is
your NPU vs. CPU benchmark for the Technical Implementation slide.

## Step 5: Run the caption overlay (Day 2)

```bash
python overlay.py --backend cpu --chunk 4
```

An always-on-top window opens with:
- **Start/Stop** — begins/ends listening
- Live captions (last 6 lines, auto-scrolling)
- **Save Transcript** — transcript is actually saved continuously as you
  speak (to `transcript.txt`); the button just confirms the path
- A running avg-latency readout — same number you'd screenshot for the
  benchmark slide
- A **"Translate to"** dropdown — currently a UI stub (it doesn't
  translate yet). It's there so the demo reads correctly; wire in the
  on-device MT model from the pitch deck's architecture slide by adding
  a translation call inside `_on_caption()` in `overlay.py` before the
  Small window ships. If you run out of time, leaving it as "Original"
  and being upfront about it in your demo is safer than a broken toggle.

Swap `--backend cpu` for `--backend qnn` once Step 3 is done — no other
code changes needed, since both engines share the same interface.
